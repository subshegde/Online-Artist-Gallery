<footer>
          <p>� 2022 Artist Gallery </p>
          <p>Website Developed by <a  class="link">Subrahmanya S Hegde and Prasanna K Hegde</a></p>
        </footer>