<!DOCTYPE html>
<html lang="en">
<head>
<title>Modern Art WiNG</title>
<?php include('meta_tag.php'); ?>
</head>
<body>
<div class="main">
  <!--==============================header=================================-->
<?PHP include('header.php'); ?>
  <!--==============================content================================-->
  <section id="content">
    <div class="container_12">
      <div class="grid_4 bot-2">
        <h2 class="top-6">Contact Us</h2>
       
        <dl>
          <dt>ARTIST GALLERY</br>
           Koushik Hegde</br>
		   Gadihalli Post: Kulve Tq:Sirsi</br>
		   Uttarakannada 581450 </br>
		   <dd><span>Instagram id: </span>artistkoushik_hegde_official</dd>
		   </dt>
           <dd><span>G-mail: </span>koushik.g.hegde@gmail.com</dd>
        </dl>
      </div>
      <div class="grid_8">
        <div class="block-1 top-5">
         
        </div><?php include('footer.php'); ?>
        <!--==============================footer=================================-->
        
      </div>
      <div class="clear"></div>
    </div>
  </section>
</div>
</body>
</html>
