  <header>
<div align="center"><img src="images/logo01.png"></div>
    <nav>
      <div id="slide">
	     <ul class="menu">
        <li class="current"><a href="index.php" class="clr-1"><img src="images/red_home_black_home_icon_black_home.png" width="35" height="35"> </a></li>
        <li><a href="about.php" class="clr-2">About</a></li>
       
        <li><a href="gallery.php" class="clr-4">Gallery</a></li>
        <li><a href="contacts.php" class="clr-5">Contact Us</a></li>
		 <li><a href="../login/index.html" class="clr-2">LOGIN</a></li>
      </ul>
        <div class="slider">
          <ul class="items">
            <li><img src="images/h2.jpg" alt=""></li>
            <li><img src="images/h1.jpg" alt=""></li>
            <li><img src="images/h2.jpg" alt=""></li>
			<li><img src="images/h1.jpg" alt=""></li>
          </ul>
        </div>
        <a href="#" class="prev"></a><a href="#" class="next"></a> </div>
   
    </nav>
  </header>